module smart_project

go 1.26.3

require (
	github.com/aead/cmac v0.0.0-20160719120800-7af84192f0b1
	github.com/dumacp/smartcard v0.1.8
	github.com/ebfe/scard v0.0.0-20241214075232-7af069cabc25
	github.com/eclipse/paho.mqtt.golang v1.5.1
	github.com/tarm/serial v0.0.0-20180830185346-98f6abe2eb07
	periph.io/x/conn/v3 v3.7.3
	periph.io/x/host/v3 v3.8.5
)

require (
	github.com/gorilla/websocket v1.5.3 // indirect
	golang.org/x/net v0.44.0 // indirect
	golang.org/x/sync v0.17.0 // indirect
	golang.org/x/sys v0.36.0 // indirect
)
